class Mysql:
    HOST = "remotemysql.com"
    USER = "MSGCLjKIA3"
    PASSWORD = "LuKGG3dyUZ"
    DB = "MSGCLjKIA3"